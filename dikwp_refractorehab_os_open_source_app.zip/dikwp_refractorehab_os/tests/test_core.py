import json, pathlib, sys
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / 'src'))
from dikwp_refractorehab.analyzer import analyze, high_myopia_score, classify_ai_request, write_outputs
from dikwp_refractorehab.static_audit import audit

def load(name):
    return json.load(open(pathlib.Path(__file__).resolve().parents[1] / name, encoding='utf-8'))

def test_high_myopia_score():
    c=load('examples/sample_refractive_rehab_case.json'); p=load('configs/default_policy.json')
    assert high_myopia_score(c,p) > 0.4

def test_guard_blocks_prescription():
    p=load('configs/default_policy.json')
    assert classify_ai_request('write prescription for my glasses',p) == 'block'

def test_outputs(tmp_path):
    root=pathlib.Path(__file__).resolve().parents[1]
    report=write_outputs(str(root/'examples/sample_refractive_rehab_case.json'), str(root/'configs/default_policy.json'), str(tmp_path))
    assert (tmp_path/'refractorehab_report.json').exists()
    assert report['overall_route'] == 'clinician_review_required'

def test_static_audit():
    root=pathlib.Path(__file__).resolve().parents[1]
    assert audit(str(root/'src'))['pass'] is True
