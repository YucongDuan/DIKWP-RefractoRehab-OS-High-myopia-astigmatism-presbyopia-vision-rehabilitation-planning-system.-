# Optical Options Matrix

Options to discuss with clinicians include high-index progressive spectacles, occupational computer/near spectacles, separate distance and near glasses, toric multifocal contacts, monovision trial, modified monovision, and low-vision/digital accessibility tools.

Each option must be evaluated by task distance, binocular tolerance, night driving safety, dry eye, lens rotation, retinal health, glaucoma/cataract considerations, adaptation burden, and reversibility.
