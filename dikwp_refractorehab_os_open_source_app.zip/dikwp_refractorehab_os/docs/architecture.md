# Architecture

Input case JSON is compiled into a DIKWP ledger. The analyzer calculates high-myopia proxy risk, detects red-flag symptoms, checks overdue exam intervals, builds decision cards, creates non-prescriptive optical option matrices, and writes a rehabilitation plan.

The system has no network calls and no medical-device control. All high-risk medical questions are routed to clinician review.
