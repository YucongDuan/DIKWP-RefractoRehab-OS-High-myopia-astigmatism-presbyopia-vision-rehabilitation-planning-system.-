# Red-Flag Policy

The system escalates if red-flag terms appear: sudden vision loss, curtain or shadow, new flashes, new floaters, sudden increase of floaters, eye trauma, painful red eye, severe headache with vision change, new distortion, black spot, chemical injury.

These cases are not handled by self-management. They require urgent professional eye-care review.
