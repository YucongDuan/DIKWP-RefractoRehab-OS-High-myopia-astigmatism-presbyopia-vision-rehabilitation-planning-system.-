# High Myopia + Astigmatism + Presbyopia Rehabilitation Protocol

1. Register the case as a refractive triad.
2. Separate optical function from ocular health risk.
3. Define task distances: distance, intermediate, near, night, mobility.
4. Prepare optical-stack questions for professional review.
5. Prepare retina/glaucoma/cataract surveillance discussion.
6. Generate screen, reading, lighting, and magnification plan.
7. Generate red-flag education card.
8. Never generate a prescription or surgery recommendation.

Key principle: rehabilitation optimizes function and safety; it does not claim to cure high myopia, astigmatism, or presbyopia.
