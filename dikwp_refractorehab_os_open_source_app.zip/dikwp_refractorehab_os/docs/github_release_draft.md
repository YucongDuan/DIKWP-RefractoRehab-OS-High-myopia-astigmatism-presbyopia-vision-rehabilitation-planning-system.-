# GitHub Release Draft

DIKWP RefractoRehab OS v0.1.0 provides an offline clinical education and rehabilitation planning prototype for adults with high myopia, astigmatism, and presbyopia. It includes CLI, standalone HTML demo, synthetic case, output reports, and static safety audit.
