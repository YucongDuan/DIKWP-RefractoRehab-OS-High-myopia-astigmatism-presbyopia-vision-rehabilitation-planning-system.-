# Rehabilitation Plan Template

- Task distance inventory.
- Lighting and glare control.
- Contrast and font-size settings.
- Reading and screen ergonomics.
- Magnification and assistive tech.
- Mobility safety.
- Dry eye and screen break discussion with clinician.
- Follow-up checklist.
