# Clinical Governance Boundary

Allowed:
- Education.
- Visual task inventory.
- Red-flag education.
- Clinician handoff drafting.
- Optical option discussion preparation.
- Low-vision and digital accessibility planning.

Not allowed:
- Glasses or contact-lens prescription generation.
- Diagnosis.
- Treatment decisions.
- Refractive surgery recommendation.
- Ignoring retinal red flags.
- Replacing ophthalmologist or optometrist examination.
