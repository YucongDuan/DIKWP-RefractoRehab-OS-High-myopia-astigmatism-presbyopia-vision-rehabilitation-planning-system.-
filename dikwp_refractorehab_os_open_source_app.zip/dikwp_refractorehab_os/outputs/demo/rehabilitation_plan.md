# Vision Rehabilitation Plan Draft

This is not a prescription. Use it as a discussion document for an ophthalmologist, optometrist, or vision rehabilitation specialist.

## Task-specific adaptations
- desktop computer: target working distance 65 cm; priority high; verify lens task distance and posture with clinician.
- phone reading: target working distance 35 cm; priority high; verify lens task distance and posture with clinician.
- printed documents: target working distance 40 cm; priority medium; verify lens task distance and posture with clinician.
- driving at night: target working distance 6000 cm; priority medium; verify lens task distance and posture with clinician.
- walking stairs / street signs: target working distance 300 cm; priority high; verify lens task distance and posture with clinician.

## Environment and device settings
- Use stable, even task lighting; avoid glare from shiny desks and screens.
- Increase font size and contrast on phone/computer; test dark mode vs light mode by comfort, not fashion.
- Use anti-glare surfaces and adjustable monitor height to reduce neck strain.
- Consider a handheld or stand magnifier only after verifying best correction and task distance.

## High myopia safety education
- Keep a visible red-flag card: sudden vision loss, new flashes/floaters, curtain/shadow, new distortion, painful red eye, trauma.
- Do not use eye exercises or app settings as substitutes for clinical evaluation.

## Follow-up discussion packet
- Bring current glasses/contact lens prescriptions, previous OCT/fundus photos, visual fields, axial length if available, and a list of failed lens experiences.