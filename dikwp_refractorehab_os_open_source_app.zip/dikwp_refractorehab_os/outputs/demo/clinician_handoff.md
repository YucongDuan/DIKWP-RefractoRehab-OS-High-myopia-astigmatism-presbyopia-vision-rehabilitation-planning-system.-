# Clinician Handoff Draft

{
  "case_id": "refractorehab-demo-001",
  "refraction": {
    "right_eye": {
      "sphere_D": -10.5,
      "cylinder_D": -2.25,
      "axis_deg": 175,
      "add_D": 2.0,
      "best_corrected_va": "20/30"
    },
    "left_eye": {
      "sphere_D": -9.75,
      "cylinder_D": -1.75,
      "axis_deg": 10,
      "add_D": 2.0,
      "best_corrected_va": "20/25"
    },
    "anisometropia_note": "Moderate symmetry; check binocular tolerance.",
    "last_refraction_months_ago": 14
  },
  "eye_health": {
    "axial_length_mm": {
      "right_eye": 28.1,
      "left_eye": 27.7
    },
    "known_conditions": [
      "high myopia",
      "astigmatism",
      "presbyopia",
      "dry eye tendency"
    ],
    "retina_history": [
      "lattice suspected but not confirmed"
    ],
    "glaucoma_history": "family history uncertain",
    "cataract_history": "early lens opacity noted two years ago",
    "last_dilated_exam_months_ago": 18,
    "last_oct_months_ago": 18,
    "last_visual_field_months_ago": 24
  },
  "symptoms": [
    "near blur with current glasses",
    "computer neck strain",
    "night glare",
    "occasional floaters long-standing, no sudden increase",
    "dryness after screen work"
  ],
  "constraints": {
    "budget_level": "medium",
    "contact_lens_tolerance": "partial",
    "surgery_interest": "curious but cautious",
    "avoidances": [
      "cannot tolerate strong swimmy progressive lens",
      "does not want irreversible surgery without trial"
    ],
    "must_preserve": [
      "driving safety",
      "retinal risk surveillance",
      "reading comfort",
      "computer posture"
    ]
  },
  "overdue_flags": [
    "refraction_overdue",
    "dilated_retina_exam_overdue",
    "oct_overdue",
    "visual_field_overdue"
  ]
}