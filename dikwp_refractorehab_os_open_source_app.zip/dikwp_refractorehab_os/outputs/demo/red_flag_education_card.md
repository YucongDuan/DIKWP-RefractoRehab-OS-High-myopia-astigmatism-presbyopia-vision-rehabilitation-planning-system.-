# Red-Flag Education Card

- sudden vision loss
- curtain
- shadow
- new flashes
- new floaters
- sudden increase floaters
- eye trauma
- painful red eye
- severe headache with vision
- new distortion
- black spot
- chemical injury

If any new acute red flag occurs, seek urgent eye care. This system is not a triage substitute.
