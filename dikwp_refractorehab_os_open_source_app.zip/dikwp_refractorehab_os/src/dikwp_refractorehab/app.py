# Optional Streamlit wrapper placeholder. Offline core does not require Streamlit.
