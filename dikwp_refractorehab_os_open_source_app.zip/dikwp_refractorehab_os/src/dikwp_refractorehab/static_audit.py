from pathlib import Path
import re
FORBIDDEN = [
    r'^\s*import\s+requests\b', r'^\s*from\s+requests\b',
    r'^\s*import\s+urllib\b', r'^\s*import\s+socket\b',
    r'^\s*import\s+subprocess\b', r'\bos\.system\s*\(',
    r'\beval\s*\(', r'\bexec\s*\(',
    r'selenium', r'playwright', r'pyautogui', r'pynput'
]

def audit(path: str):
    root=Path(path); findings=[]
    for p in root.rglob('*.py'):
        if p.name == 'static_audit.py':
            continue
        text=p.read_text(encoding='utf-8')
        for pat in FORBIDDEN:
            if re.search(pat, text, re.I|re.M):
                findings.append({'file':str(p),'pattern':pat})
    return {'pass': not findings, 'finding_count': len(findings), 'findings': findings, 'policy': 'No network imports, subprocess, dynamic execution, browser automation, device control, or clinical decision automation in offline core.'}
