from dataclasses import dataclass, asdict
from typing import Any, Dict, List

@dataclass
class DecisionCard:
    area: str
    decision: str
    risk_score: float
    rationale: str
    required_reviewer: str
    action: str
    kill_conditions: List[str]
    recovery: List[str]

@dataclass
class DIKWPRecord:
    object_id: str
    D: Dict[str, Any]
    I: Dict[str, Any]
    K: Dict[str, Any]
    W: Dict[str, Any]
    P: Dict[str, Any]
    R: Dict[str, Any]

    def to_dict(self):
        return asdict(self)
