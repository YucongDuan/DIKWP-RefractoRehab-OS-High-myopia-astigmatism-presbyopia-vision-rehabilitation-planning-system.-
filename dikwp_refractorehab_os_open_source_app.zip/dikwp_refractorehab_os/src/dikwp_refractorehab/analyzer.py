import json, math, re
from pathlib import Path
from typing import Any, Dict, List
from .models import DecisionCard, DIKWPRecord


def load_json(path: str) -> Dict[str, Any]:
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def spherical_equivalent(eye: Dict[str, Any]) -> float:
    return float(eye.get('sphere_D', 0)) + 0.5 * float(eye.get('cylinder_D', 0))


def high_myopia_score(case: Dict[str, Any], policy: Dict[str, Any]) -> float:
    ref = case.get('refraction', {})
    eyes = [ref.get('right_eye', {}), ref.get('left_eye', {})]
    se_scores = []
    for e in eyes:
        se = spherical_equivalent(e)
        se_scores.append(clamp((abs(se) - 6) / 8))
    axial = case.get('eye_health', {}).get('axial_length_mm', {})
    axial_scores = []
    for val in axial.values():
        try:
            axial_scores.append(clamp((float(val) - 26.0) / 4.0))
        except Exception:
            pass
    return round(max(se_scores + axial_scores + [0]), 3)


def red_flags(case: Dict[str, Any], policy: Dict[str, Any]) -> List[str]:
    text = ' '.join(case.get('red_flag_symptoms', []) + case.get('symptoms', []))
    found = []
    for t in policy.get('red_flag_terms', []):
        if re.search(re.escape(t), text, flags=re.I):
            found.append(t)
    return sorted(set(found))


def overdue_flags(case: Dict[str, Any], policy: Dict[str, Any]) -> List[str]:
    health = case.get('eye_health', {})
    ref = case.get('refraction', {})
    th = policy.get('risk_thresholds', {})
    flags = []
    if ref.get('last_refraction_months_ago', 0) > th.get('refraction_overdue_months', 12):
        flags.append('refraction_overdue')
    if health.get('last_dilated_exam_months_ago', 0) > th.get('retina_exam_overdue_months', 12):
        flags.append('dilated_retina_exam_overdue')
    if health.get('last_oct_months_ago', 0) > th.get('oct_overdue_months', 12):
        flags.append('oct_overdue')
    if health.get('last_visual_field_months_ago', 0) > th.get('visual_field_overdue_months', 18):
        flags.append('visual_field_overdue')
    return flags


def classify_ai_request(text: str, policy: Dict[str, Any]) -> str:
    lower = text.lower()
    for term in policy.get('blocked_ai_requests', []):
        if term in lower:
            return 'block'
    risky = ['surgery', 'contact lens parameter', 'retinal', 'glaucoma', 'anti-vegf', 'laser', 'drive']
    if any(t in lower for t in risky):
        return 'clinician_review_required'
    return 'allow_education_or_rehab_planning'


def build_dikwp(case: Dict[str, Any], hm_score: float, reds: List[str], overdue: List[str]) -> List[Dict[str, Any]]:
    profile = case.get('profile', {})
    ref = case.get('refraction', {})
    health = case.get('eye_health', {})
    records = []
    records.append(DIKWPRecord(
        object_id='refractive_triad',
        D={'refraction': ref, 'age': profile.get('age'), 'symptoms': case.get('symptoms', [])},
        I={'triad': ['high_myopia', 'astigmatism', 'presbyopia'], 'task_context': profile.get('daily_visual_tasks', [])},
        K={'mechanism': 'distance focus error + meridional blur + age-related near focusing loss; exact correction requires clinical refraction and binocular tolerance testing'},
        W={'boundaries': ['do not generate prescription', 'do not replace comprehensive eye exam', 'protect driving safety and retinal risk surveillance']},
        P={'goal': profile.get('primary_goal'), 'success': ['comfortable reading', 'safer mobility', 'task-specific optical options prepared for clinician review']},
        R={'high_myopia_score': hm_score, 'red_flags': reds, 'overdue': overdue, 'reliability': 'educational planning only'}
    ).to_dict())
    records.append(DIKWPRecord(
        object_id='retina_glaucoma_surveillance',
        D={'axial_length': health.get('axial_length_mm'), 'retina_history': health.get('retina_history'), 'glaucoma_history': health.get('glaucoma_history')},
        I={'risk_context': 'high myopia / long axial length increases need for careful retinal and optic nerve surveillance'},
        K={'checks_to_discuss': ['dilated retina exam', 'OCT macula', 'OCT RNFL/GCC', 'visual field', 'fundus photography', 'IOP and optic nerve review']},
        W={'boundaries': ['urgent symptoms require clinical care', 'screening tools cannot rule out retinal tear or glaucoma alone']},
        P={'goal': 'avoid missed sight-threatening complications while supporting daily visual function'},
        R={'overdue': overdue, 'red_flags': reds, 'reliability': 'clinician review required'}
    ).to_dict())
    return records


def decision_cards(case: Dict[str, Any], policy: Dict[str, Any]) -> List[DecisionCard]:
    hm = high_myopia_score(case, policy)
    reds = red_flags(case, policy)
    overdue = overdue_flags(case, policy)
    cards = []
    if reds:
        cards.append(DecisionCard('red_flag_boundary','urgent_ophthalmology_review',1.0,
                                  'Sight-threatening symptoms or risk terms detected.', 'ophthalmologist / emergency eye care',
                                  'Stop self-management and seek urgent eye evaluation.',
                                  ['new curtain/shadow/flashes/floaters/sudden vision loss'], ['urgent clinical evaluation']))
    else:
        cards.append(DecisionCard('red_flag_boundary','education_and_monitoring',0.2,
                                  'No acute red flag terms in current input; still educate due to high myopia.', 'patient + clinician at next review',
                                  'Generate red-flag education card and keep emergency triggers visible.',
                                  ['new acute symptoms'], ['upgrade to urgent review']))
    if hm >= 0.5 or overdue:
        cards.append(DecisionCard('retina_glaucoma_surveillance','clinician_review_required',clamp(0.4+hm+0.1*len(overdue)),
                                  'High myopia/axial length and overdue surveillance items require eye-care professional review.', 'ophthalmologist',
                                  'Prepare surveillance checklist: dilated retina exam, OCT macula/RNFL, IOP, visual field, fundus photos.',
                                  ['new red flags', 'unexplained visual field loss', 'new distortion'], ['schedule professional exam; update ledger with results']))
    cards.append(DecisionCard('optical_stack','optometrist_or_ophthalmologist_refraction_review',0.55,
                              'High myopia + astigmatism + presbyopia creates multi-distance and binocular tolerance issues.', 'optometrist / ophthalmologist',
                              'Compare high-index progressive, occupational/computer glasses, toric/multifocal contact lens, monovision trial, and low-vision aids as review options, without generating a prescription.',
                              ['diplopia', 'unsafe night driving', 'lens intolerance'], ['trial frame/contact lens trial; task-specific refinement']))
    cards.append(DecisionCard('rehabilitation_environment','allow_rehab_planning',0.25,
                              'Environment, contrast, lighting, font size, screen distance, and magnification can be planned without changing medical treatment.', 'vision rehabilitation specialist / patient',
                              'Generate task-specific lighting, contrast, magnification, screen, posture, and mobility plan.',
                              ['persistent inability to perform daily tasks despite correction'], ['refer for vision rehabilitation and low-vision device assessment']))
    cards.append(DecisionCard('surgery_interest','specialist_counseling_only',0.75,
                              'High refractive error and presbyopia may prompt interest in refractive surgery or lens procedures; suitability depends on retina, cornea, lens, IOP, age and goals.', 'refractive surgeon + retina/ophthalmology review',
                              'Generate questions for clinician; do not recommend surgery.',
                              ['patient wants irreversible surgery based only on app output'], ['obtain comprehensive evaluation and second opinion if needed']))
    return cards


def optical_options(case: Dict[str, Any]) -> List[Dict[str, str]]:
    return [
        {'option': 'custom progressive spectacles', 'use': 'general daily distance/intermediate/near', 'review_questions': 'high-index material, frame size, vertex distance, corridor length, astigmatism axis tolerance, adaptation plan'},
        {'option': 'occupational computer/reading glasses', 'use': 'long screen and desk work', 'review_questions': 'intermediate focal distance, near segment, posture and neck strain reduction'},
        {'option': 'single vision distance + dedicated near', 'use': 'night driving or tasks needing stable distance optics', 'review_questions': 'separate task pairs may reduce distortion compared with one all-purpose lens'},
        {'option': 'toric multifocal contact lens trial', 'use': 'field-of-view and spectacle-minification reduction', 'review_questions': 'dry eye, lens rotation, cylinder axis stability, near add, eye health risk'},
        {'option': 'monovision / modified monovision trial', 'use': 'selected presbyopic patients', 'review_questions': 'trial before permanent change; depth perception and night driving tolerance'},
        {'option': 'low-vision aids / digital accessibility', 'use': 'if best-corrected vision or visual field limits daily function', 'review_questions': 'magnifier, screen reader, contrast, task lighting, orientation safety'}
    ]


def rehab_plan(case: Dict[str, Any]) -> str:
    tasks = case.get('profile', {}).get('daily_visual_tasks', [])
    lines = ['# Vision Rehabilitation Plan Draft', '', 'This is not a prescription. Use it as a discussion document for an ophthalmologist, optometrist, or vision rehabilitation specialist.', '']
    lines += ['## Task-specific adaptations']
    for t in tasks:
        task = t.get('task')
        dist = t.get('distance_cm')
        priority = t.get('priority')
        lines.append(f'- {task}: target working distance {dist} cm; priority {priority}; verify lens task distance and posture with clinician.')
    lines += ['', '## Environment and device settings', '- Use stable, even task lighting; avoid glare from shiny desks and screens.', '- Increase font size and contrast on phone/computer; test dark mode vs light mode by comfort, not fashion.', '- Use anti-glare surfaces and adjustable monitor height to reduce neck strain.', '- Consider a handheld or stand magnifier only after verifying best correction and task distance.', '', '## High myopia safety education', '- Keep a visible red-flag card: sudden vision loss, new flashes/floaters, curtain/shadow, new distortion, painful red eye, trauma.', '- Do not use eye exercises or app settings as substitutes for clinical evaluation.', '', '## Follow-up discussion packet', '- Bring current glasses/contact lens prescriptions, previous OCT/fundus photos, visual fields, axial length if available, and a list of failed lens experiences.']
    return '\n'.join(lines)


def analyze(case: Dict[str, Any], policy: Dict[str, Any]) -> Dict[str, Any]:
    hm = high_myopia_score(case, policy)
    reds = red_flags(case, policy)
    overdue = overdue_flags(case, policy)
    cards = decision_cards(case, policy)
    requests = [{'request': r, 'decision': classify_ai_request(r, policy)} for r in case.get('requested_ai_tasks', [])]
    report = {
        'system': 'DIKWP RefractoRehab OS',
        'version': '0.1.0',
        'case_id': case.get('case_id'),
        'decision_summary': {c.decision: sum(1 for x in cards if x.decision == c.decision) for c in cards},
        'high_myopia_score': hm,
        'red_flags': reds,
        'overdue_flags': overdue,
        'overall_route': 'urgent_review' if reds else ('clinician_review_required' if overdue or hm > .5 else 'education_and_rehab_planning'),
        'action_boundary': 'Education, rehabilitation planning, clinician handoff, and optical-option comparison only; no prescription, diagnosis, surgery recommendation, or emergency triage replacement.',
        'request_guard': requests,
        'semantic_stability': 'S3 Supported Closure' if not reds else 'S1 Fragile Closure due to red flags'
    }
    return report


def write_outputs(case_path: str, policy_path: str, out_dir: str) -> Dict[str, Any]:
    case, policy = load_json(case_path), load_json(policy_path)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    report = analyze(case, policy)
    hm = high_myopia_score(case, policy); reds=red_flags(case, policy); overdue=overdue_flags(case, policy)
    ledger = build_dikwp(case, hm, reds, overdue)
    cards = decision_cards(case, policy)
    options = optical_options(case)
    (out/'refractorehab_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'dikwp_vision_ledger.json').write_text(json.dumps(ledger, ensure_ascii=False, indent=2), encoding='utf-8')
    import csv
    with open(out/'decision_cards.csv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f, fieldnames=['area','decision','risk_score','required_reviewer','action','rationale'])
        w.writeheader(); [w.writerow({'area':c.area,'decision':c.decision,'risk_score':c.risk_score,'required_reviewer':c.required_reviewer,'action':c.action,'rationale':c.rationale}) for c in cards]
    with open(out/'optical_options_matrix.csv','w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f, fieldnames=['option','use','review_questions']); w.writeheader(); w.writerows(options)
    red_report = {'red_flags': reds, 'if_present': 'urgent eye-care review; do not rely on app self-management', 'education_terms': policy.get('red_flag_terms', [])}
    (out/'red_flag_education_card.md').write_text('# Red-Flag Education Card\n\n' + '\n'.join([f'- {x}' for x in policy.get('red_flag_terms', [])]) + '\n\nIf any new acute red flag occurs, seek urgent eye care. This system is not a triage substitute.\n', encoding='utf-8')
    (out/'rehabilitation_plan.md').write_text(rehab_plan(case), encoding='utf-8')
    handoff = '# Clinician Handoff Draft\n\n' + json.dumps({'case_id':case.get('case_id'),'refraction':case.get('refraction'),'eye_health':case.get('eye_health'),'symptoms':case.get('symptoms'),'constraints':case.get('constraints'),'overdue_flags':overdue}, ensure_ascii=False, indent=2)
    (out/'clinician_handoff.md').write_text(handoff, encoding='utf-8')
    (out/'task_distance_profile.json').write_text(json.dumps(case.get('profile',{}).get('daily_visual_tasks',[]), ensure_ascii=False, indent=2), encoding='utf-8')
    (out/'ai_request_guard_report.json').write_text(json.dumps(report['request_guard'], ensure_ascii=False, indent=2), encoding='utf-8')
    return report
