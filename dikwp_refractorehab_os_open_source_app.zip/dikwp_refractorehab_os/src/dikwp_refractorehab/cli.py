import argparse, json
from .analyzer import write_outputs, classify_ai_request
from .static_audit import audit

def main():
    ap=argparse.ArgumentParser(prog='refractorehab')
    sub=ap.add_subparsers(dest='cmd')
    a=sub.add_parser('analyze'); a.add_argument('case'); a.add_argument('--policy', default='configs/default_policy.json'); a.add_argument('--out', default='outputs/demo')
    g=sub.add_parser('guard'); g.add_argument('text'); g.add_argument('--policy', default='configs/default_policy.json')
    s=sub.add_parser('static-audit'); s.add_argument('path'); s.add_argument('--out')
    ns=ap.parse_args()
    if ns.cmd=='analyze':
        print(json.dumps(write_outputs(ns.case, ns.policy, ns.out), ensure_ascii=False, indent=2))
    elif ns.cmd=='guard':
        policy=json.load(open(ns.policy,encoding='utf-8'))
        print(json.dumps({'text':ns.text,'decision':classify_ai_request(ns.text,policy)}, ensure_ascii=False, indent=2))
    elif ns.cmd=='static-audit':
        res=audit(ns.path)
        if ns.out: open(ns.out,'w',encoding='utf-8').write(json.dumps(res, ensure_ascii=False, indent=2))
        print(json.dumps(res, ensure_ascii=False, indent=2))
    else:
        ap.print_help()
if __name__ == '__main__': main()
